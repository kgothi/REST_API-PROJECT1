var mysql = require('mysql');
var bcrypt = require('bcrypt-nodejs');
const dbconfig = require('../config/database');
//var connection = mysql.createConnection(dbconfig.connection);
const express = require('express');
const router = express.Router();
var body = require('body-parser');

//connection.query('USE ' + dbconfig.database);

router.use(body.urlencoded({extended: false}));

var connection = mysql.createConnection({  
    host: "localhost",  
    user: "root",  
    password: "",  
    database: "matcha"  
    });  

router.get('/', (req, res, next) => {
        res.render('../views/register.ejs');
});

router.post('/register', function(req, res){
        
                var newUseMysql = {
                    firstname : req.body.firstname,
                    lastname : req.body.lastname,
                    mobilenumber : req.body.mobilenumber,
                    idnumber : req.body.idnumber,
                    physicaladdress : req.body.physicaladdress,
                };
                console.log(newUseMysql);
               // var  insertQuery = "INSERT INTO users (username, password) values(?, ?)";

                dbconfig.query("INSERT INTO users (firstname, lastname, mobilenumber, idnumber,physicaladdress) values (?,?,?,?, ?)", [newUseMysql.firstname,newUseMysql.lastname, newUseMysql.mobilenumber,newUseMysql.idnumber, newUseMysql.physicaladdress], function(err, rows){
                   // newUseMysql.id = rows.insertId;
                   //console.log(err);
                   //res.render('./login');
                     res.render('./');
                    //return done(null, newUseMysql);
                    //successRedirect: '/profile'

                });
 });


module.exports = router;