var localStrategy = require("passport-local").Strategy;
var mysql = require('mysql');
var bcrypt = require('bcrypt-nodejs');
const dbconfig = require('./database');
var connection = mysql.createConnection(dbconfig.connection);
connection.query('USE ' + dbconfig.database);

module.exports = function(passport) {
    passport.serializeUser(function(user, done){
        done(null, user.id);
    });

    passport.deserializeUser(function(id, done) {
        connection.query("SELECT * FROM users WHERE id = ? ", [id],function(err, rows) {
            done(err, rows[0]);
        });
    });

passport.use(
    'local-signup',
    new localStrategy({
        firstnameField : "firstname",
        lastnameField : "lastname",
        mobilenumber : "mobilenumber",
        idnumber : "idnumber",
        physicaladdress : "physicaladdress",
        passReqToCallback : true

    },
    function(req, username, password, done){
        connection.query("SELECT * FROM users WHERE idnumber = ?", [idnumber], function(err, rows){
            if(err)
                return done(err);
            if(rows.length){
                return done(null, false, req.flash('signupMessage', 'That is already taken'));
            }else{
                var newUseMysql = {
                    firstname : firstname,
                    lastname : Lastname,
                    mobilenumber : mobilenumber,
                    idnumber : idnumber,
                    physicaladdress : physicaladdress,
                };
                var  insertQuery = "INSERT INTO users (firstname, lastname, mobileaddress, idnumber, physicaladdress) values(?,?,?,?, ?)";

                connection.query(insertQuery, [newUseMysql.firstname,newUseMysql.lastname, newUseMysql.mobilenumber,newUseMysql.idnumber, newUseMysql.physicaladdress], function(err, rows){
                    newUseMysql.id = rows.insertId;

                    return done(null, newUseMysql);
                });
            } 
        });
    })
    );
// passport.use(
//     'local-login',
//     new localStrategy({
//         usernameField : 'username',
//         passwordField : 'password',
//         passReqToCallback: true
//     },
//     function(req, username, password, done){
//         connection.query("SELECT * FROM users WHERE username = ?", [username], function(err, rows){
//             if(err)
//                 return done(err);
//             if(!rows.length){
//                 return done(null, false, req.flash('loginMessage', 'No User found'));
//             }
//             if(!bcrypt.compareSync(password, rows[0].password))
//                 return done(null, false, req.flash('loginMessage', 'Wrong Password'));
             
//             return done(null, row[0]);   
//         });
//     })
//     );
//passport.use();
    
};