const session = require('express-session');
var cookiesParser = require('cookie-parser');
var bodyParser = require('body-parser');
// var morgan = require('morgan');
var mysql = require('mysql');
var bcrypt = require('bcrypt-nodejs');
const dbconfig = require('./config/database');
const express = require('express');
const cons = require('consolidate');
var index = require('./router');
var register = require('./router/register');
const path = require('path');
const app = express();

app.set('view engine','ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.engine('ejs', cons.swig)
app.set('views', path.join(__dirname, 'views'))
//app.set('view engine', 'ejs')
app.use(session({secret: 'randomstringsessionsecret'}));

app.use('/',index);
app.use('/register', register);
//app.use('/logout', logout)
//app.post()

//app.post()
app.listen(3000, () =>{
    console.log('sever is running on port 3000 .....');
});


module.exports = app